import id.ac.dinus.lib.*;
import id.ac.dinus.test.*;

public class AksesLib {
    public static void main(String[] args) {
        MyLib myLib = new MyLib();
        myLib.cetak();
        YourLib yourLib = new YourLib();
        yourLib.cetak2();
        HisLib hisLib = new HisLib();
        hisLib.cetak3();
    }
}
