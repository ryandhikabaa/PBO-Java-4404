package id.ac.dinus.test;

import id.ac.dinus.lib.*;

public class HisLib {
    public void cetak3() {
        MyLib myLib = new MyLib();
        myLib.cetak();
        System.out.println("his lib cetak()..........");
    }
}
