package id.ac.dinus.lib;

public class YourLib {
    public void cetak2() {
        System.out.println("Cetak YourLib.....");
    }
}
