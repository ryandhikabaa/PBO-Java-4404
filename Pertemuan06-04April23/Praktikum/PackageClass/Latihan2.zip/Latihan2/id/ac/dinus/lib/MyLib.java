package id.ac.dinus.lib;

public class MyLib {
    public void cetak() {
        System.out.println("MyLib.cetak.....");
    }
}
